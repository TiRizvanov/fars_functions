[![Build Status](https://travis-ci.org/jmab20/farsfuncs.svg?branch=master)](https://travis-ci.org/jmab20/farsfuncs)

# farsfuncs
Building an R Package task for Johns Hopkins University (coursera)
